import React, { useState, useLayoutEffect, useEffect } from "react";
import { Platform, TouchableOpacity } from "react-native";
import { View, Text, StyleSheet, TextInput } from "react-native";
import { Button } from "react-native-elements";
import { LinearGradient } from "expo-linear-gradient";
import Feather from "react-native-vector-icons/Feather";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import * as Animatable from "react-native-animatable";
import { StatusBar } from "react-native";
import { auth, db, storage } from "../../firebase";

const RegisterScreen = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [friends, setFriends] = useState([]);
  const [request, setRequest] = useState([]);
  const [message, setMessage] = useState([]);
  const [error, setError] = useState("");
  const [image, setImage] = useState(null);
  const [confirm_password, setConfirmPassword] = useState("");
  const [check_emailInputChange, setEmailInputChange] = useState(false);
  const [check_nameInputChange, setNameInputChange] = useState(false);
  const [secureTextEntry, setSecureTextEntry] = useState(true);
  const [confirm_secureTextEntry, setConfirmSecureTextEntry] = useState(true);
  const [checkPassword, setCheckPassword] = useState(false);

  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    });
  }, [navigation]);

  // const passChecker = () => {
  //   const err = { message: "passwords do not match" };
  //   const errh = { message: "please fill in details" };

  //   if (confirm_password && password === "") {
  //     setError(errh);
  //   } else {
  //     setError(err);
  //   }
  // };

  const textEmailChange = (val) => {
    if (val.includes("@")) {
      setEmail(val);
      setEmailInputChange(true);
    } else {
      setEmailInputChange(false);
    }
  };

  const textNameChange = (val) => {
    if (val.includes("@")) {
      setName(val);
      setNameInputChange(true);
    } else {
      setEmailInputChange(false);
    }
  };

  const handlePasswordChange = (val) => {
    setPassword(val);
  };

  const handleConfirmPasswordChange = (val) => {
    setConfirmPassword(val);
  };

  const UpdatesecureTextEntry = () => {
    setSecureTextEntry(!secureTextEntry);
  };

  const UpdateConfirmSecureTextEntry = () => {
    setConfirmSecureTextEntry(!confirm_secureTextEntry);
  };

  const register = async () => {
    await auth
      .createUserWithEmailAndPassword(email.toLowerCase(), password)

      .then((authUser) => {
        authUser.user.updateProfile({
          displayName: name.toLowerCase(),
          photoURL:
            imageUrl ||
            "https://racemph.com/wp-content/uploads/2016/09/profile-image-placeholder.png",
        });
      })
      .catch((err) => setError(err));
    db.collection("user").add({
      email: email.toLowerCase(),
      password: password,
      displayName: name.toLowerCase(),
      photoURL: imageUrl,
      friends: friends,
      request: request,
      uid: auth.currentUser.uid,
    });
  };

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#009387" barStyle="light-content" />
      <View style={styles.header}>
        <Text style={styles.text_header}>Register Now</Text>
      </View>

      <Animatable.View style={styles.footer} animation="fadeInUpBig">
        <Text style={styles.text_footer}>Username </Text>
        <View style={styles.action}>
          <FontAwesome name="user-o" color="#05375a" size={20} />
          <TextInput
            placeholder="Your Username"
            style={styles.textInput}
            autoCapitalize="none"
            onChangeText={(val) => textNameChange(val)}
          />
          {check_nameInputChange ? (
            <Animatable.View animation="bounceIn">
              <Feather name="check-circle" color="green" size={20} />
            </Animatable.View>
          ) : null}
        </View>

        <Text style={[styles.text_footer, { marginTop: 20 }]}>Email </Text>
        <View style={styles.action}>
          <Feather name="mail" color="#05375a" size={20} />
          <TextInput
            placeholder="Your Email"
            style={styles.textInput}
            autoCapitalize="none"
            onChangeText={(val) => textEmailChange(val)}
          />
          {check_emailInputChange ? (
            <Animatable.View animation="bounceIn">
              <Feather name="check-circle" color="green" size={20} />
            </Animatable.View>
          ) : null}
        </View>

        <Text style={(styles.text_footer, { marginTop: 20 })}>Password </Text>
        <View style={styles.action}>
          <FontAwesome name="lock" color="#05375a" size={20} />
          <TextInput
            placeholder="Your Password"
            secureTextEntry={secureTextEntry ? true : false}
            style={styles.textInput}
            autoCapitalize="none"
            onChangeText={(val) => handlePasswordChange(val)}
          />
          <TouchableOpacity onPress={UpdatesecureTextEntry}>
            {secureTextEntry ? (
              <Feather name="eye-off" color="grey" size={20} />
            ) : (
              <Feather name="eye" color="grey" size={20} />
            )}
          </TouchableOpacity>
        </View>

        <Text style={(styles.text_footer, { marginTop: 20 })}>
          Confirm Password{" "}
        </Text>
        <View style={styles.action}>
          <FontAwesome name="lock" color="#05375a" size={20} />
          <TextInput
            placeholder="Your Password"
            secureTextEntry={confirm_secureTextEntry ? true : false}
            style={styles.textInput}
            autoCapitalize="none"
            onChangeText={(val) => handleConfirmPasswordChange(val)}
          />
          <TouchableOpacity onPress={UpdateConfirmSecureTextEntry}>
            {confirm_secureTextEntry ? (
              <Feather name="eye-off" color="grey" size={20} />
            ) : (
              <Feather name="eye" color="grey" size={20} />
            )}
          </TouchableOpacity>
        </View>

        <View
          style={{
            alignItems: "center",
            justifyContent: "center",
            marginTop: 10,
          }}
        >
          <Text style={{ color: "red" }}>{error.message}</Text>
        </View>

        <View style={styles.button}>
          <TouchableOpacity style={styles.signIn} onPress={register}>
            <LinearGradient
              colors={["#08d4c4", "#01ab9d"]}
              style={styles.signIn}
            >
              <Text style={[styles.textSign, { color: "#fff" }]}>Sign Up</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}
            style={[
              styles.signIn,
              {
                borderColor: "#009387",
                borderWidth: 1,
                marginTop: 15,
              },
            ]}
          >
            <Text style={[styles.textSign, { color: "#009387" }]}>Sign In</Text>
          </TouchableOpacity>
        </View>
      </Animatable.View>
    </View>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#009387",
  },
  header: {
    flex: 0.5,
    justifyContent: "flex-end",
    paddingHorizontal: 20,
    paddingBottom: 50,
  },
  footer: {
    flex: 4,
    backgroundColor: "#fff",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingVertical: 20,
    paddingHorizontal: 30,
  },

  text_header: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 30,
  },
  text_footer: {
    color: "#05375a",
    fontSize: 18,
  },
  action: {
    flexDirection: "row",
    marginTop: 10,
    borderBottomWidth: 1,
    borderRightColor: "#f2f2f2",
    paddingBottom: 5,
  },
  textInput: {
    flex: 1,
    marginTop: Platform.OS === "ios" ? 0 : -12,
    paddingLeft: 10,
    color: "#05375a",
  },
  button: {
    alignItems: "center",
    marginTop: 30,
  },
  signIn: {
    width: "100%",
    height: 35,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
  },
  textSign: {
    fontSize: 18,
    fontWeight: "bold",
  },
});
