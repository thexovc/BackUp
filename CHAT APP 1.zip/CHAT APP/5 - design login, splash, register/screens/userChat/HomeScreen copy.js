import React, { useEffect, useLayoutEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  SafeAreaView,
  TouchableOpacity,
} from "react-native";
import { Avatar } from "react-native-elements";
import CustomListItem from "../../components/CustomListItem";
import UserListItem from "../../components/userListItem";
import { auth, db } from "../../firebase";
import {
  AntDesign,
  SimpleLineIcons,
  Octicons,
  FontAwesome,
} from "@expo/vector-icons";

const HomeScreen = ({ navigation }) => {
  const [chats, setChats] = useState([]);
  const [name, setName] = useState([]);
  const [photoURL, setPhotoURL] = useState([]);
  const [pic, setPic] = useState([]);

  const signOutUser = async () => {
    auth.signOut().then(() => {
      !auth.currentUser
        ? navigation.replace("Login")
        : navigation.replace("Home");
    });
  };

  useEffect(() => {
    const unsubscribe = db
      .collection("request")
      .doc(auth.currentUser.uid)
      .collection("friends")
      .onSnapshot((snapshot) =>
        setChats(
          snapshot.docs.map((doc) => ({
            id: doc.id,
            data: doc.data(),
          })),
          setName(
            snapshot.docs.map((doc) => ({
              name: doc.data().name,
            }))
          ),
          setPhotoURL(
            snapshot.docs.map((doc) => ({
              photoURL: doc.data().photoURL,
            }))
          ),
          setPic(
            snapshot.docs.map((doc) => ({
              pic: doc.data().photoURL,
            }))
          )
        )
      );
    return unsubscribe;
  }, []);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "MyChatApp",
      headerStyle: { backgroundColor: "#fff" },
      headerTitleStyle: { color: "black" },
      headerTintColor: { color: "black" },
      headerLeft: () => (
        <View style={{ marginLeft: 20 }}>
          <TouchableOpacity onPress={signOutUser} activeOpacity={0.5}>
            <Avatar rounded source={{ uri: auth?.currentUser?.photoURL }} />
          </TouchableOpacity>
        </View>
      ),
      headerRight: () => (
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            width: 80,
            marginRight: 20,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.5}
            onPress={() => navigation.navigate("Request")}
          >
            <Octicons name="request-changes" size={24} color="black" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navigation.navigate("AddChat")}
            activeOpacity={0.5}
          >
            <FontAwesome name="search" size={24} color="black" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navigation.navigate("ProfilePicture")}
            activeOpacity={0.5}
          >
            <SimpleLineIcons name="pencil" size={24} color="black" />
          </TouchableOpacity>
        </View>
      ),
    });
  }, [navigation]);

  const enterChat = (id, name, photoURL) => {
    navigation.navigate("Chat", {
      id,

      pic: pic,
      name: name,
    });
  };

  return (
    <SafeAreaView>
      <ScrollView style={styles.container}>
        {chats.map(({ id, data: { name, photoURL } }) => (
          <UserListItem
            key={id}
            id={id}
            chatName={name}
            photoURL={photoURL}
            enterChat={enterChat}
          />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    height: "100%",
  },
});
