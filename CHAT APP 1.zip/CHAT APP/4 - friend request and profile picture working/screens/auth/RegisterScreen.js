import { StatusBar } from "expo-status-bar";
import React, { useState, useLayoutEffect, useEffect } from "react";
import { KeyboardAvoidingView, StyleSheet, View, Platform } from "react-native";
import { Button, Input, Image, Text } from "react-native-elements";
import { ScrollView } from "react-native-gesture-handler";
import ProfilePicture from "../../components/profilePicture";
import { auth, db, storage } from "../../firebase";

import * as ImagePicker from "expo-image-picker";
import { Alert } from "react-native";

const RegisterScreen = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [friends, setFriends] = useState([]);
  const [request, setRequest] = useState([]);
  const [message, setMessage] = useState([]);
  const [image, setImage] = useState(null);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerBackTitle: "Back to Login",
    });
  }, [navigation]);

  const register = async () => {
    await auth
      .createUserWithEmailAndPassword(email.toLowerCase(), password)

      .then((authUser) => {
        authUser.user.updateProfile({
          displayName: name.toLowerCase(),
          photoURL:
            imageUrl ||
            "https://racemph.com/wp-content/uploads/2016/09/profile-image-placeholder.png",
        });
      })
      .catch((error) => alert(error.message));
    db.collection("user").add({
      email: email.toLowerCase(),
      password: password,
      displayName: name.toLowerCase(),
      photoURL: imageUrl,
      friends: friends,
      request: request,
      uid: auth.currentUser.uid,
    });
  };

  return (
    <ScrollView>
      <KeyboardAvoidingView behavior="padding" style={styles.container}>
        <StatusBar style="light" />
        <Text h3 style={{ marginBottom: 15, marginTop: 30 }}>
          Create a Signal account
        </Text>

        <View style={styles.inputContainer}>
          <Input
            placeholder="Full Name"
            autoFocus
            value={name}
            type="text"
            onChangeText={(text) => setName(text)}
          />
          <Input
            placeholder="Email"
            value={email}
            type="email"
            onChangeText={(text) => setEmail(text)}
          />
          <Input
            placeholder="Password"
            value={password}
            secureTextEntry
            type="password"
            onChangeText={(text) => setPassword(text)}
          />
        </View>
        <View style={{ padding: 50 }}></View>
        <Button raised onPress={register} title="Register" />
      </KeyboardAvoidingView>
    </ScrollView>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
  },
  inputContainer: {
    width: 300,
  },
  button: {
    width: 200,
    marginTop: 20,
  },
});
