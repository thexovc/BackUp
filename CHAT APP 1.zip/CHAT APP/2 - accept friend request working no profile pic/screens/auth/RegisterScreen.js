import { StatusBar } from "expo-status-bar";
import React, { useState, useLayoutEffect } from "react";
import { KeyboardAvoidingView, StyleSheet, View } from "react-native";
import { Button, Input, Image, Text } from "react-native-elements";
import { ScrollView } from "react-native-gesture-handler";
import ProfilePicture from "../../components/profilePicture";
import { auth, db } from "../../firebase";

const RegisterScreen = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [friends, setFriends] = useState([]);
  const [request, setRequest] = useState([]);
  const [message, setMessage] = useState([]);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerBackTitle: "Back to Login",
    });
  }, [navigation]);

  const register = async () => {
    await auth
      .createUserWithEmailAndPassword(email, password)

      .then((authUser) => {
        authUser.user.updateProfile({
          displayName: name,
          photoURL:
            imageUrl ||
            "https://racemph.com/wp-content/uploads/2016/09/profile-image-placeholder.png",
        });
      })
      .catch((error) => alert(error.message));
    db.collection("user").add({
      email: email,
      password: password,
      displayName: name,
      photoURL: imageUrl,
      friends: friends,
      request: request,
      uid: auth.currentUser.uid,
    });
  };

  return (
    <ScrollView>
      <KeyboardAvoidingView behavior="padding" style={styles.container}>
        <StatusBar style="light" />
        <Text h3 style={{ marginBottom: 15, marginTop: 30 }}>
          Create a Signal account
        </Text>

        <View style={styles.inputContainer}>
          <Input
            placeholder="Full Name"
            autoFocus
            value={name}
            type="text"
            onChangeText={(text) => setName(text)}
          />
          <Input
            placeholder="Email"
            value={email}
            type="email"
            onChangeText={(text) => setEmail(text)}
          />
          <Input
            placeholder="Password"
            value={password}
            secureTextEntry
            type="password"
            onChangeText={(text) => setPassword(text)}
          />
          <View style={{ padding: 20 }}></View>
          <ProfilePicture />
          {/* 
          <Input
            placeholder="Profile Picture URL (optional)"
            value={imageUrl}
            type="text"
            value={imageUrl}
            onChangeText={(text) => setImageUrl(text)}
            onSubmitEditing={register}
          /> */}
        </View>
        <View style={{ padding: 50 }}></View>
        <Button raised onPress={register} title="Register" />
      </KeyboardAvoidingView>
    </ScrollView>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 10,
  },
  inputContainer: {
    width: 300,
  },
  button: {
    width: 200,
    marginTop: 20,
  },
});
