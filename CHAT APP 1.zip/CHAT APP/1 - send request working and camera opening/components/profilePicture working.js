import React, { useState, useEffect, useLayoutEffect } from "react";
import { Button, Image, View, Platform, TouchableOpacity } from "react-native";
import * as ImagePicker from "expo-image-picker";
import Constants from "expo-constants";
import { db, storage, auth } from "../firebase";
import {
  AntDesign,
  SimpleLineIcons,
  Octicons,
  FontAwesome,
} from "@expo/vector-icons";
import { Alert } from "react-native";
import { uuid } from "uuidv4";
import path from "react-native-path";

export default function ProfilePicture({ navigation }) {
  const [image, setImage] = useState(null);

  // useEffect(() => {
  //   (async () => {
  //     if (Platform.OS !== "web") {
  //       const {
  //         status,
  //       } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  //       if (status !== "granted") {
  //         alert("Sorry, we need camera roll permissions to make this work!");
  //       }
  //     }
  //   })();
  // }, []);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerBackTitle: "Back to Login",
    });
  }, [navigation]);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "Edit Profile Picture",
      headerStyle: { backgroundColor: "#fff" },
      headerTitleStyle: { color: "black" },
      headerTintColor: { color: "black" },

      headerRight: () => (
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            width: 80,
            marginRight: 20,
          }}
        >
          <TouchableOpacity
            activeOpacity={0.5}
            onPress={() => navigation.navigate("Request")}
          >
            <Octicons name="request-changes" size={24} color="black" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navigation.navigate("AddChat")}
            activeOpacity={0.5}
          >
            <FontAwesome name="search" size={24} color="black" />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navigation.navigate("ProfilePicture")}
            activeOpacity={0.5}
          >
            <SimpleLineIcons name="pencil" size={24} color="black" />
          </TouchableOpacity>
        </View>
      ),
    });
  }, [navigation]);

  const onChooseImagePress = async () => {
    // let result = await ImagePicker.launchCameraAsync();
    let result = await ImagePicker.launchImageLibraryAsync();

    if (!result.cancelled) {
      uploadImage(result.uri, "test-image")
        .then(() => {
          // Alert.alert("Success");
          console.log("success");
          // setImage(result.uri);
        })
        .catch((error) => {
          // Alert.alert(error);
          console.log(error);
        });
    }
  };

  const uploadImage = async (uri, imageName) => {
    const fileName = imageName + path.extname(uri);
    const response = await fetch(uri);
    const blob = await response.blob();
    const ext = path.extname(uri).split(".").pop();

    let ref = storage.ref().child("images/" + imageName);

    var metadata = {
      // contentType: `image/${path.extname(uri).split(".").pop()}`,
      contentType: "image/jpeg",
    };

    return ref.put(blob, metadata);
  };

  // const uploadImage = async (uri, imageName) => {
  //   const response = await fetch(uri);
  //   const blob = await response.blob;

  //   let ref = storage.ref().child("images/" + imageName + ".jpg");
  //   // const uuidv4 = require("uuid/v4");

  //   const { v4: uuidv4 } = require("uuid");

  //   const uuidf = uuidv4();

  //   var metadata = {
  //     contentType: "image/jpeg",

  //     firebaseStorageDownloadTokens: uuidf, //In this line you are adding the access token
  //   };
  //   return ref.put(blob, metadata);
  // };

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Button title="Choose image..." onPress={onChooseImagePress} />
    </View>
  );
}
