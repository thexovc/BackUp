import React, { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { Avatar, Button, ListItem } from "react-native-elements";
import { auth, db } from "../firebase";

const FriendRequest = ({ id, chatName, enterChat, photoURL, email, uid }) => {
  const [chatMessages, setchatMessages] = useState([]);
  const acceptM = () => {
    db.collection("request")
      .doc(Fuid)
      .collection("friends")
      .add({
        name: auth.currentUser.displayName,
        id: auth.currentUser.uid,
        email: auth.currentUser.email,
        photoURL: auth.currentUser.photoURL,
        chatParams: `${auth.currentUser.displayName + Fname}`,
      });
  };

  const acceptF = () => {
    db.collection("request")
      .doc(auth.currentUser.uid)
      .collection("friends")
      .add({
        name: Fname,
        id: Fuid,
        email: Femail,
        photoURL: FphotoURL,
        chatParams: `${auth.currentUser.displayName + Fname}`,
      });
  };

  useEffect(() => {
    const unsubscribe = db
      .collection("chats")
      .doc(`${auth.currentUser.displayName + chatName}`)
      .collection("message")
      .orderBy("timestamp", "desc")
      .onSnapshot((snapshot) =>
        setchatMessages(snapshot.docs.map((doc) => doc.data()))
      );
    return unsubscribe;
  });
  return <Text>Hellloo</Text>;
};

export default FriendRequest;

const styles = StyleSheet.create({});
