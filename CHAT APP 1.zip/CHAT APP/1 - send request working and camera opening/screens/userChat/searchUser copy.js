import React, { useLayoutEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { Button, Input } from "react-native-elements";
import Icon from "react-native-vector-icons/FontAwesome";
import { Avatar, ListItem } from "react-native-elements";
import { auth, db } from "../../firebase";

const SearchUser = ({ navigation, route }) => {
  const [input, setInput] = useState("");
  const [result, setResult] = useState([]);
  const [chatParams, setChatParams] = useState("");
  const [message, setMessage] = useState([]);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "Search for Friends",
      headerBackTitle: "Chats",
    });
  }, []);

  const searchChat = async () => {
    // display the input as a list

    const citiesRef = db.collection("user");
    const snapshot = await citiesRef.where("displayName", "==", input).get();
    if (snapshot.empty) {
      console.log("No matching documents.");
      return;
    }

    snapshot.forEach((doc) => {
      setResult(snapshot.docs.map((doc) => doc.data()));
    });
  };

  const chatParamsString = chatParams.toString();

  return (
    <View style={styles.container}>
      <Input
        placeholder="Enter a User Name"
        value={input}
        onChangeText={(text) => setInput(text)}
        leftIcon={
          <Icon name="wechat" type="antdesign" size={24} color="black" />
        }
      />
      <Button disabled={!input} onPress={searchChat} title="Search for User" />
      <View>
        <ListItem bottomDivider>
          <ListItem.Content>
            {result.map((data) => (
              <>
                <View style={{ marginTop: 20 }}>
                  <Avatar
                    rounded
                    source={{
                      uri:
                        data.photoURL ||
                        "https://www.dovercourt.org/wp-content/uploads/2019/11/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.jpg",
                    }}
                  />

                  <ListItem.Title key={data.id} style={{ fontWeight: "800" }}>
                    {data.displayName}
                  </ListItem.Title>
                  <ListItem.Subtitle numberOfLines={1} ellipsizeMode="tail">
                    {data.uid}
                  </ListItem.Subtitle>
                  <ListItem.Title
                    onPress={db
                      .collection("request")
                      .doc(auth.currentUser.uid)
                      .collection("friends")
                      .add({
                        name: data.displayName,
                        id: data.uid,
                        email: data.email,
                        photoURL: data.photoURL,
                        chatParams: `${
                          auth.currentUser.displayName + data.displayName
                        }`,
                      })}
                    key={data.id}
                    style={{ fontWeight: "800" }}
                  >
                    <ListItem.Title
                      onPress={db
                        .collection("request")
                        .doc(data.uid)
                        .collection("friends")
                        .add({
                          name: auth.currentUser.displayName,
                          id: auth.currentUser.uid,
                          email: auth.currentUser.email,
                          photoURL: auth.currentUser.photoURL,
                          chatParams: `${
                            auth.currentUser.displayName + data.displayName
                          }`,
                        })}
                      key={data.id}
                      style={{ fontWeight: "800" }}
                    >
                      <ListItem.Title
                        onPress={db
                          .collection("chats")
                          .doc(
                            `${data.displayName + auth.currentUser.displayName}`
                          )
                          .collection("message")
                          .add({
                            photoURL: data.photoURL,
                          })}
                        key={data.id}
                        style={{ fontWeight: "800" }}
                      >
                        <ListItem.Title
                          onPress={() =>
                            db
                              .collection("chats")
                              .doc(
                                `${
                                  auth.currentUser.displayName +
                                  data.displayName
                                }`
                              )
                              .collection("message")
                              .add({
                                photoURL: auth.currentUser.photoURL,
                              })
                          }
                          key={data.id}
                          style={{ fontWeight: "800" }}
                        >
                          Add User
                        </ListItem.Title>
                      </ListItem.Title>
                    </ListItem.Title>
                  </ListItem.Title>
                </View>
              </>
            ))}
          </ListItem.Content>
        </ListItem>
      </View>
    </View>
  );
};

export default SearchUser;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    padding: 50,
    height: "100%",
  },
});
