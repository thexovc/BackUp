import React, { useLayoutEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { Button, Input } from "react-native-elements";
import Icon from "react-native-vector-icons/FontAwesome";
import { Avatar, ListItem } from "react-native-elements";
import { auth, db } from "../../firebase";

const FriendRequest = ({ navigation, route }) => {
  const [input, setInput] = useState("");
  const [result, setResult] = useState([]);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "Friend Request",
      headerBackTitle: "Chats",
    });
  }, []);

  const acceptRequest = async () => {};

  return (
    <View style={styles.container}>
      <View>
        <ListItem.Content>
          {result.map((data) => (
            <>
              <View style={{ marginTop: 20 }}>
                <Avatar
                  rounded
                  source={{
                    uri:
                      data.photoURL ||
                      "https://www.dovercourt.org/wp-content/uploads/2019/11/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.jpg",
                  }}
                />

                <ListItem.Title key={data.id} style={{ fontWeight: "800" }}>
                  {data.displayName}
                </ListItem.Title>
                <ListItem.Subtitle numberOfLines={1} ellipsizeMode="tail">
                  {data.uid}
                </ListItem.Subtitle>
                <ListItem.Title
                  onPress={db
                    .collection("request")
                    .doc(auth.currentUser.uid)
                    .collection("friends")
                    .add({
                      name: data.displayName,
                      id: data.uid,
                      email: data.email,
                      photoURL: data.photoURL,
                    })}
                  key={data.id}
                  style={{ fontWeight: "800" }}
                >
                  Add User
                </ListItem.Title>
              </View>
            </>
          ))}
        </ListItem.Content>
      </View>
    </View>
  );
};

export default FriendRequest;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    padding: 50,
    height: "100%",
  },
});

// <ListItem.Content>
//   {result.map((data) => (
//     <>
//       <View style={{ marginTop: 20 }}>
//         <Avatar
//           rounded
//           source={{
//             uri:
//               data.photoURL ||
//               "https://www.dovercourt.org/wp-content/uploads/2019/11/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.jpg",
//           }}
//         />

//         <ListItem.Title key={data.id} style={{ fontWeight: "800" }}>
//           {data.displayName}
//         </ListItem.Title>
//         <ListItem.Subtitle numberOfLines={1} ellipsizeMode="tail">
//           {data.uid}
//         </ListItem.Subtitle>
//         <ListItem.Title
//           onPress={db
//             .collection("request")
//             .doc(auth.currentUser.uid)
//             .collection("friends")
//             .add({
//               name: data.displayName,
//               id: data.uid,
//               email: data.email,
//               photoURL: data.photoURL,
//             })}
//           key={data.id}
//           style={{ fontWeight: "800" }}
//         >
//           <ListItem.Title
//             onPress={db
//               .collection("request")
//               .doc(data.uid)
//               .collection("friends")
//               .add({
//                 name: auth.currentUser.displayName,
//                 id: auth.currentUser.uid,
//                 email: auth.currentUser.email,
//                 photoURL: auth.currentUser.photoURL,
//               })}
//             key={data.id}
//             style={{ fontWeight: "800" }}
//           >
//             Add User
//           </ListItem.Title>
//         </ListItem.Title>
//       </View>
//     </>
//   ))}
// </ListItem.Content>;
