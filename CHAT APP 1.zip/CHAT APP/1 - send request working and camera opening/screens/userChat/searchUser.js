import React, { useLayoutEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { Button, Input } from "react-native-elements";
import Icon from "react-native-vector-icons/FontAwesome";
import { Avatar, ListItem } from "react-native-elements";
import { auth, db } from "../../firebase";

const SearchUser = ({ navigation, route }) => {
  const [input, setInput] = useState("");
  const [result, setResult] = useState([]);
  const [chatParams, setChatParams] = useState("");
  const [message, setMessage] = useState([]);
  const [accept, setAccept] = useState(false);

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "Search for Friends",
      headerBackTitle: "Chats",
    });
  }, []);

  const searchChat = async () => {
    // display the input as a list

    const citiesRef = db.collection("user");
    const snapshot = await citiesRef.where("displayName", "==", input).get();
    if (snapshot.empty) {
      console.log("No matching documents.");
      return;
    }

    snapshot.forEach((doc) => {
      setResult(snapshot.docs.map((doc) => doc.data()));
    });
  };

  const chatParamsString = chatParams.toString();

  const Ur = (dat) => {
    db.collection("request")
      .doc(auth.currentUser.uid)
      .collection("quest")
      .add({
        name: dat.displayName,
        id: dat.uid,
        email: dat.email,
        accept: accept,
        photoURL: dat.photoURL,
        chatParams: `${auth.currentUser.displayName + dat.displayName}`,
      });
  };

  const Fr = (dat) => {
    db.collection("request")
      .doc(dat.uid)
      .collection("quest")
      .add({
        name: auth.currentUser.displayName,
        id: auth.currentUser.uid,
        email: auth.currentUser.email,
        accept: accept,
        photoURL: auth.currentUser.photoURL,
        chatParams: `${auth.currentUser.displayName + dat.displayName}`,
      });
  };

  return (
    <View style={styles.container}>
      <Input
        placeholder="Enter a User Name"
        value={input}
        onChangeText={(text) => setInput(text)}
        leftIcon={
          <Icon name="wechat" type="antdesign" size={24} color="black" />
        }
      />
      <Button disabled={!input} onPress={searchChat} title="Search for User" />
      <View>
        <ListItem bottomDivider>
          <ListItem.Content>
            {result.map((data) => (
              <>
                <View style={{ marginTop: 20 }}>
                  <View style={styles.resultContainer}>
                    <View style={{ flex: 1 }}>
                      <Avatar
                        rounded
                        source={{
                          uri:
                            data.photoURL ||
                            "https://www.dovercourt.org/wp-content/uploads/2019/11/610-6104451_image-placeholder-png-user-profile-placeholder-image-png.jpg",
                        }}
                      />
                    </View>
                    <Text
                      onPress={() => {
                        Ur(data);
                        Fr(data);
                      }}
                      key={data.id}
                      style={{
                        fontWeight: "800",
                        flex: 1,
                        alignItems: "center",
                        textAlign: "center",
                        justifyContent: "center",
                        paddingTop: 3,
                      }}
                    >
                      Add User
                    </Text>
                  </View>

                  <ListItem.Title key={data.id} style={{ fontWeight: "800" }}>
                    {data.displayName}
                  </ListItem.Title>
                  <ListItem.Subtitle
                    numberOfLines={1}
                    ellipsizeMode="tail"
                    style={{ color: "white" }}
                  >
                    ---------------------------------------
                  </ListItem.Subtitle>
                </View>
              </>
            ))}
          </ListItem.Content>
        </ListItem>
      </View>
    </View>
  );
};

export default SearchUser;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    padding: 50,
    height: "100%",
  },
  resultContainer: {
    flexDirection: "row",
  },
});

// <Text
// onPress={db
//   .collection("chats")
//   .doc(
//     `${
//       data.displayName + auth.currentUser.displayName
//     }`
//   )
//   .collection("message")
//   .add({
//     photoURL: data.photoURL,
//   })}
// key={data.id}
// style={{
//   fontWeight: "800",
//   flex: 1,
//   alignItems: "center",
//   textAlign: "center",
//   justifyContent: "center",
//   paddingTop: 3,
// }}
// >
// <Text
//   onPress={() =>
//     db
//       .collection("chats")
//       .doc(
//         `${
//           auth.currentUser.displayName +
//           data.displayName
//         }`
//       )
//       .collection("message")
//       .add({
//         photoURL: auth.currentUser.photoURL,
//       })
//   }
//   key={data.id}
//   style={{
//     fontWeight: "800",
//     flex: 1,
//     alignItems: "center",
//     textAlign: "center",
//     justifyContent: "center",
//     paddingTop: 3,
//   }}
// >
//   <Icon
//     name="user-plus"
//     type="fontawesome"
//     size={24}
//     color="grey"
//   />
// </Text>
// </Text>
