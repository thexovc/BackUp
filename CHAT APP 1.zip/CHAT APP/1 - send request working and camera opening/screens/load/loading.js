import React, { useEffect, useLayoutEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  SafeAreaView,
  TouchableOpacity,
  ImageBackground,
} from "react-native";
import { Avatar, ListItem, withTheme, Image } from "react-native-elements";

// import CustomListItem from "../../components/CustomListItem";
import { auth, db } from "../../firebase";
import { AntDesign, SimpleLineIcons } from "@expo/vector-icons";
import { StatusBar } from "expo-status-bar";

const Loading = ({ navigation }) => {
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((authUser) => {
      if (authUser) {
        navigation.replace("Home");
      } else {
        navigation.replace("Login");
      }
    });

    return unsubscribe;
  }, []);

  return (
    <ImageBackground
      style={styles.background}
      source={{ uri: "https://wallpaperaccess.com/full/2213426.jpg" }}
    >
      {/* <View style={styles.container}>
        <Text style={styles.h1}>Welcome to MyChatApp</Text>
        <Text style={styles.h2}>
          Get Closer to the people around you ( ^ ** ^ )!!
        </Text>
      </View> */}
    </ImageBackground>
  );
};

export default Loading;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  h1: {
    width: "100%",

    color: "white",
    fontSize: 40,
    marginBottom: 10,
    fontFamily: "monospace",
    textAlign: "center",
  },
  h2: {
    width: "100%",

    color: "white",
    fontSize: 15,
    marginTop: 10,
    fontFamily: "monospace",
    textAlign: "center",
  },
  image: {
    width: "100%",
    height: 400,
  },
});
